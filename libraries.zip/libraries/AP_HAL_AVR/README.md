AVR is only supported on its separate [branch](https://github.com/ArduPilot/ardupilot/tree/master-AVR)
