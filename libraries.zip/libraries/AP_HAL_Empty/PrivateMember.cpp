
#include "PrivateMember.h"

using namespace Empty;

PrivateMember::PrivateMember(uint16_t foo) :
    _foo(foo)
{}

void PrivateMember::init() {}

