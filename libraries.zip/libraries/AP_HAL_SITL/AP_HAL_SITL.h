#pragma once

#include <AP_HAL/AP_HAL.h>

#if CONFIG_HAL_BOARD == HAL_BOARD_SITL

#include "HAL_SITL_Class.h"

#endif // CONFIG_HAL_BOARD
